# FaceUp 2.0

Aplicativo web/PWA em português.

## Arquivos
- index.html — aplicativo
- manifest.json — configuração de instalação
- sw.js — cache/offline e atualização
- icons/ — ícones do aplicativo

## Instalação
Para o Chrome reconhecer a instalação como PWA, os arquivos precisam estar publicados em um endereço HTTPS (por exemplo, GitHub Pages).
Abra o endereço no Chrome e use o menu do Chrome > Adicionar à tela inicial / Instalar aplicativo, quando a opção aparecer.

Observação: o HTML usa algumas bibliotecas externas (Tailwind CDN, Lucide e canvas-confetti), então a primeira abertura precisa de internet para carregá-las. O Service Worker mantém o app shell disponível depois de carregado.
